$(document).ready(function() {
    $('.datepicker').datepicker({
      appendTo: '.modal-content' // Specify the parent element where the datepicker should be appended
    });
  });